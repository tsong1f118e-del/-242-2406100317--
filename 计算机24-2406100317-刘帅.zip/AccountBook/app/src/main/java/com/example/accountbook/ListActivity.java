package com.example.accountbook;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

/**
 * 账单页：接收 Intent 传来的记录，用 ListView 展示，并统计收入/支出/结余。
 * 点击某一条会跳转到详情页（第二次 Intent 传值）。
 */
public class ListActivity extends AppCompatActivity {

    private ArrayList<Record> records = new ArrayList<>();

    @SuppressWarnings({"unchecked", "deprecation"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        // 接收上一个页面传来的数据
        Object data = getIntent().getSerializableExtra("records");
        if (data instanceof ArrayList) {
            records = (ArrayList<Record>) data;
        }

        TextView tvSummary = findViewById(R.id.tvSummary);
        ListView listView = findViewById(R.id.listView);
        Button btnBack = findViewById(R.id.btnBack);

        // 统计
        double income = 0;
        double expense = 0;
        for (Record r : records) {
            if (r.isIncome()) {
                income += r.getAmount();
            } else {
                expense += r.getAmount();
            }
        }
        tvSummary.setText(String.format(Locale.CHINA,
                "收入 %.2f 元    支出 %.2f 元    结余 %.2f 元",
                income, expense, income - expense));

        listView.setAdapter(new RecordAdapter(this, records));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListActivity.this, DetailActivity.class);
                intent.putExtra("record", records.get(position));
                intent.putExtra("index", position + 1);
                startActivity(intent);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /** 自定义适配器：把 Record 显示到 item_record 布局上 */
    private static class RecordAdapter extends BaseAdapter {
        private final Context context;
        private final ArrayList<Record> data;

        RecordAdapter(Context context, ArrayList<Record> data) {
            this.context = context;
            this.data = data;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = LayoutInflater.from(context).inflate(R.layout.item_record, parent, false);
            }
            TextView tvCategory = view.findViewById(R.id.tvItemCategory);
            TextView tvSub = view.findViewById(R.id.tvItemSub);
            TextView tvAmount = view.findViewById(R.id.tvItemAmount);

            Record r = data.get(position);
            tvCategory.setText(r.getCategory());

            String sub = r.getTime();
            if (!r.getNote().isEmpty()) {
                sub = sub + "  " + r.getNote();
            }
            tvSub.setText(sub);

            if (r.isIncome()) {
                tvAmount.setText(String.format(Locale.CHINA, "+%.2f", r.getAmount()));
                tvAmount.setTextColor(Color.parseColor("#2E7D32"));
            } else {
                tvAmount.setText(String.format(Locale.CHINA, "-%.2f", r.getAmount()));
                tvAmount.setTextColor(Color.parseColor("#C62828"));
            }
            return view;
        }
    }
}
