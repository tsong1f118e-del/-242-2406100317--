package com.example.accountbook;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * 记账页：录入收支，并跳转到账单页（Intent 传值）。
 * 用到的控件：TextView、EditText、Button、RadioGroup、Spinner、CheckBox、ImageButton、Toast
 */
public class MainActivity extends AppCompatActivity {

    private final ArrayList<Record> records = new ArrayList<>();

    private RadioGroup rgType;
    private Spinner spCategory;
    private EditText etAmount;
    private EditText etNote;
    private CheckBox cbNecessary;
    private Button btnSave;
    private Button btnView;
    private ImageButton ibClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initSpinner();
        initListeners();
    }

    private void initViews() {
        rgType = findViewById(R.id.rgType);
        spCategory = findViewById(R.id.spCategory);
        etAmount = findViewById(R.id.etAmount);
        etNote = findViewById(R.id.etNote);
        cbNecessary = findViewById(R.id.cbNecessary);
        btnSave = findViewById(R.id.btnSave);
        btnView = findViewById(R.id.btnView);
        ibClear = findViewById(R.id.ibClear);
    }

    private void initSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategory.setAdapter(adapter);
    }

    private void initListeners() {
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveRecord();
            }
        });

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openList();
            }
        });

        ibClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearInputs();
                Toast.makeText(MainActivity.this, "已清空输入", Toast.LENGTH_SHORT).show();
            }
        });

        // 选择"收入"时，"必要支出"复选框没有意义，直接禁用
        rgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean isExpense = (checkedId == R.id.rbExpense);
                cbNecessary.setEnabled(isExpense);
                if (!isExpense) {
                    cbNecessary.setChecked(false);
                }
            }
        });
    }

    /** 校验输入并保存一条记录 */
    private void saveRecord() {
        String amountText = etAmount.getText().toString().trim();
        if (amountText.isEmpty()) {
            Toast.makeText(this, "请输入金额", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "金额格式不正确", Toast.LENGTH_SHORT).show();
            return;
        }
        if (amount <= 0) {
            Toast.makeText(this, "金额必须大于 0", Toast.LENGTH_SHORT).show();
            return;
        }

        String type = (rgType.getCheckedRadioButtonId() == R.id.rbIncome) ? "收入" : "支出";
        String category = spCategory.getSelectedItem().toString();
        String note = etNote.getText().toString().trim();
        boolean necessary = cbNecessary.isChecked();
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(new Date());

        records.add(new Record(type, category, amount, note, necessary, time));
        Toast.makeText(this, "保存成功，共 " + records.size() + " 条", Toast.LENGTH_SHORT).show();
        clearInputs();
    }

    /** 跳转到账单页，并通过 Intent 把全部记录传过去 */
    private void openList() {
        if (records.isEmpty()) {
            Toast.makeText(this, "还没有记录，先记一笔吧", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(MainActivity.this, ListActivity.class);
        intent.putExtra("records", records); // ArrayList<Record> 可序列化
        startActivity(intent);
    }

    private void clearInputs() {
        etAmount.setText("");
        etNote.setText("");
        cbNecessary.setChecked(false);
        spCategory.setSelection(0);
        rgType.check(R.id.rbExpense);
    }
}
