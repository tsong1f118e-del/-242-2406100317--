package com.example.accountbook;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

/**
 * 详情页：展示从账单页点击传来的单条记录。
 */
public class DetailActivity extends AppCompatActivity {

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView tvDetail = findViewById(R.id.tvDetail);
        Button btnBack = findViewById(R.id.btnBack);

        Object data = getIntent().getSerializableExtra("record");
        int index = getIntent().getIntExtra("index", 0);

        if (data instanceof Record) {
            Record r = (Record) data;
            String necessaryText = r.isIncome() ? "—" : (r.isNecessary() ? "是" : "否");
            String text = String.format(Locale.CHINA,
                    "第 %d 条记录\n\n类型：%s\n分类：%s\n金额：%.2f 元\n必要支出：%s\n备注：%s\n时间：%s",
                    index, r.getType(), r.getCategory(), r.getAmount(), necessaryText,
                    r.getNote().isEmpty() ? "无" : r.getNote(), r.getTime());
            tvDetail.setText(text);
        } else {
            tvDetail.setText("没有收到数据");
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
