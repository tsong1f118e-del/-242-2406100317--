package com.example.accountbook;

import java.io.Serializable;

/**
 * 一条账单记录。实现 Serializable 后，可以通过 Intent.putExtra 在 Activity 之间传递。
 */
public class Record implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String type;       // "收入" 或 "支出"
    private final String category;   // 分类
    private final double amount;     // 金额
    private final String note;       // 备注
    private final boolean necessary; // 是否必要支出
    private final String time;       // 记录时间

    public Record(String type, String category, double amount,
                  String note, boolean necessary, String time) {
        this.type = type;
        this.category = category;
        this.amount = amount;
        this.note = note;
        this.necessary = necessary;
        this.time = time;
    }

    public String getType() { return type; }
    public String getCategory() { return category; }
    public double getAmount() { return amount; }
    public String getNote() { return note; }
    public boolean isNecessary() { return necessary; }
    public String getTime() { return time; }

    public boolean isIncome() {
        return "收入".equals(type);
    }
}
